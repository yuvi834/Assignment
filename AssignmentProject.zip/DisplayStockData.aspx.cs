﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace AssignmentProject
{
    public partial class DisplayStockData : System.Web.UI.Page
    {
        String sqlcon = ConfigurationManager.ConnectionStrings["item"].ConnectionString;
        SqlConnection con; DataTable dt;
        protected void Page_Load(object sender, EventArgs e)
        {
            con = new SqlConnection(sqlcon);
            con.Open();

            SqlCommand cmd = new SqlCommand("SP_DisplayStockData",con);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            dt = new DataTable();
            sda.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            
            SqlConnection con = new SqlConnection(sqlcon);
            con.Open();
            SqlCommand cmd = new SqlCommand("SP_InsertCodeQuantity", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Item_Code",txtitem.Text);
            cmd.Parameters.AddWithValue("@qty", txtqty.Text);
            cmd.ExecuteNonQuery();         
            GridView1.DataBind();
            con.Close();
            
        }

        protected void Button2_Click(object sender, EventArgs e)
        {

        }
    }
}