﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace AssignmentProject
{
    public partial class Calculator : System.Web.UI.Page
    {
        String sqlcon = ConfigurationManager.ConnectionStrings["item"].ConnectionString;
        static float a, c, d;
        static char b;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn0_Click(object sender, EventArgs e)
        {
            if ((txtAns.Text == "+") || (txtAns.Text == "-") || (txtAns.Text == "*") || (txtAns.Text == "/"))
            {
                txtAns.Text = "";
                txtAns.Text = txtAns.Text + btn0.Text;
            }
            else
                txtAns.Text = txtAns.Text + btn0.Text;
        }

        protected void btn1_Click(object sender, EventArgs e)
        {
            if ((txtAns.Text == "+") || (txtAns.Text == "-") || (txtAns.Text == "*") || (txtAns.Text == "/"))
            {
                txtAns.Text = "";
                txtAns.Text = txtAns.Text + btn1.Text;
            }
            else
                txtAns.Text = txtAns.Text + btn1.Text;
        }
        protected void btn2_Click(object sender, EventArgs e)
        {
            if ((txtAns.Text == "+") || (txtAns.Text == "-") || (txtAns.Text == "*") || (txtAns.Text == "/"))
            {
                txtAns.Text = "";
                txtAns.Text = txtAns.Text + btn2.Text;
            }
            else
                txtAns.Text = txtAns.Text + btn2.Text;
        }

        protected void btn3_Click(object sender, EventArgs e)
        {
            if ((txtAns.Text == "+") || (txtAns.Text == "-") || (txtAns.Text == "*") || (txtAns.Text == "/"))
            {
                txtAns.Text = "";
                txtAns.Text = txtAns.Text + btn3.Text;
            }
            else
                txtAns.Text = txtAns.Text + btn3.Text;
        }

        protected void btn4_Click(object sender, EventArgs e)
        {
            if ((txtAns.Text == "+") || (txtAns.Text == "-") || (txtAns.Text == "*") || (txtAns.Text == "/"))
            {
                txtAns.Text = "";
                txtAns.Text = txtAns.Text + btn4.Text;
            }
            else
                txtAns.Text = txtAns.Text + btn4.Text;
        }

        protected void btn5_Click(object sender, EventArgs e)
        {
            if ((txtAns.Text == "+") || (txtAns.Text == "-") || (txtAns.Text == "*") || (txtAns.Text == "/"))
            {
                txtAns.Text = "";
                txtAns.Text = txtAns.Text + btn5.Text;
            }
            else
                txtAns.Text = txtAns.Text + btn5.Text;
        }

        protected void btn6_Click(object sender, EventArgs e)
        {
            if ((txtAns.Text == "+") || (txtAns.Text == "-") || (txtAns.Text == "*") || (txtAns.Text == "/"))
            {
                txtAns.Text = "";
                txtAns.Text = txtAns.Text + btn6.Text;
            }
            else
                txtAns.Text = txtAns.Text + btn6.Text;
        }

        protected void btn7_Click(object sender, EventArgs e)
        {
            if ((txtAns.Text == "+") || (txtAns.Text == "-") || (txtAns.Text == "*") || (txtAns.Text == "/"))
            {
                txtAns.Text = "";
                txtAns.Text = txtAns.Text + btn7.Text;
            }
            else
                txtAns.Text = txtAns.Text + btn7.Text;
        }

        protected void btn8_Click(object sender, EventArgs e)
        {
            if ((txtAns.Text == "+") || (txtAns.Text == "-") || (txtAns.Text == "*") || (txtAns.Text == "/"))
            {
                txtAns.Text = "";
                txtAns.Text = txtAns.Text + btn8.Text;
            }
            else
                txtAns.Text = txtAns.Text + btn8.Text;
        }

        protected void btn9_Click(object sender, EventArgs e)
        {
            if ((txtAns.Text == "+") || (txtAns.Text == "-") || (txtAns.Text == "*") || (txtAns.Text == "/"))
            {
                txtAns.Text = "";
                txtAns.Text = txtAns.Text + btn9.Text;
            }
            else
                txtAns.Text = txtAns.Text + btn9.Text;
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            a = Convert.ToInt32(txtAns.Text);
            txtAns.Text = "";
            b = '+';
            txtAns.Text += b;
        }

        protected void btnDiv_Click(object sender, EventArgs e)
        {
            a = Convert.ToInt32(txtAns.Text);
            txtAns.Text = "";
            b = '/';
            txtAns.Text += b;
        }
        protected void btnMul_Click(object sender, EventArgs e)
        {
            a = Convert.ToInt32(txtAns.Text);
            txtAns.Text = "";
            b = '*';
            txtAns.Text += b;
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            txtAns.Text = "";
        }
        protected void btnSub_Click(object sender, EventArgs e)
        {
            a = Convert.ToInt32(txtAns.Text);
            txtAns.Text = "";
            b = '-';
            txtAns.Text += b;
        }
        protected void btnEquals_Click(object sender, EventArgs e)
        {
            c = Convert.ToInt32(txtAns.Text);
            txtAns.Text = "";
            if (b == '/')
            {
                d = a / c;
                txtAns.Text += d;
                a = d;
            }
            else if (b == '+')
            {
                d = a + c;
                txtAns.Text += d;
                a = d;
            }
            else if (b == '-')
            {
                d = a - c;
                txtAns.Text += d;
                a = d;
            }
            else
            {
                d = a * c;
                txtAns.Text += d;
                a = d;
            }
        } 
        protected void btnStore_Click(object sender, EventArgs e)
        {
            String sqlcon = ConfigurationManager.ConnectionStrings["item"].ConnectionString;
            SqlConnection con = new SqlConnection(sqlcon);
            con.Open();
            SqlCommand cmd = new SqlCommand("SP_StoreAns", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Ans", txtAns.Text);
            int i = cmd.ExecuteNonQuery();
            if (i>0)
            {
                lblresult.Text = "Result store into the Database";
            }
            else
            {
                lblresult.Text = "Error while saving data";
            }

            con.Close();
        }
    }
}