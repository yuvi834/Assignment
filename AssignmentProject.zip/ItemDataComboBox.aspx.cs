﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AssignmentProject
{
    public partial class ItemDataComboBox : System.Web.UI.Page
    {
        SqlDataAdapter dadapter;
        DataSet dset;      
        string sql = "Select * from ITEM_DATA";
        String sqlcon = ConfigurationManager.ConnectionStrings["item"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {
                dadapter = new SqlDataAdapter(sql, sqlcon);
                dset = new DataSet();
                dadapter.Fill(dset);
                DropDownList1.DataSource = dset.Tables[0];
                DropDownList1.DataTextField = "RATE";
                DropDownList1.DataValueField = "ID";
                DropDownList1.DataBind();
                GridViewBind();
            }

        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {

            GridViewBind();            

        }
        public void GridViewBind()
        {
            dadapter = new SqlDataAdapter("select * from ITEM_DATA where ID=" + DropDownList1.SelectedValue + "", sqlcon);
            dset = new DataSet();
            dadapter.Fill(dset);
            GridView1.DataSource = dset.Tables[0];
            GridView1.DataBind();
        }
    }
}