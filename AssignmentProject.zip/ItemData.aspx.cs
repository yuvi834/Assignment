﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace AssignmentProject
{
    public partial class ItemData : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            String sqlcon = ConfigurationManager.ConnectionStrings["item"].ConnectionString;       
            SqlConnection con = new SqlConnection(sqlcon);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            String sqlquery = "select * from ITEM_DATA where DESCRIPTION like '%'+@DESCRIPTION+'%'";
            cmd.CommandText = sqlquery;
            cmd.Connection = con;
            cmd.Parameters.AddWithValue("DESCRIPTION", txtSearch.Text);
            DataTable dt = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            sda.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();          
        }
    }
} 