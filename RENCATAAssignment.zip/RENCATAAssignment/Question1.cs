﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RENCATAAssignment
{
    class Question1
    {
        static void mul_table(int N, int i)
        {         
            if (i > 12)
                return;
            
            Console.WriteLine(N + " * " + i + " = " + N * i);
                 
            mul_table(N, i + 1);
            Console.ReadLine();
        }
    
        public static void Main()
        {
             
            int N = 2;        
            mul_table(N, 1);
        }
       
    }
}
