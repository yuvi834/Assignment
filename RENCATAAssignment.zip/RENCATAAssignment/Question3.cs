﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RENCATAAssignment
{
    class Question3
    {
        static int NO_OF_CHARS = 256;
     
        static void fillCharCounts(String str,int[] count)
        {
            for (int i = 0; i < str.Length; i++)
                count[str[i]]++;
        }

        /* Print duplicates present in the passed string */
        static void printDups(String str)
        {


            int[] count = new int[NO_OF_CHARS];
            fillCharCounts(str, count);

            for (int i = 0; i < NO_OF_CHARS; i++)
                if (count[i] > 1)
                    Console.WriteLine((char)i + ", " +"count = " + count[i]);
        }
    
        public static void Main()
        {
            String str = "test string";
            printDups(str);
            Console.ReadLine();
        }
    }
}
