﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RENCATAAssignment
{
    class Question4
    {
        static bool isNumber(string s)
        {
            for (int i = 0; i < s.Length; i++)
                if (char.IsDigit(s[i]) == false)
                    return false;

            return true;
        }
    
        static public void Main(String[] args)
        {
          
            string str = "1234";       
            if (isNumber(str))
                Console.WriteLine("Integer");        
            else
                Console.WriteLine("String");
            Console.ReadLine();
        }
    }
}
