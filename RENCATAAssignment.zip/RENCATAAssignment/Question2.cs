﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RENCATAAssignment
{
    class Question2
    {
        static int reversDigits(int num)
        {
            int rev_num = 0;
            while (num > 0)
            {
                rev_num = rev_num * 10 + num % 10;
                num = num / 10;
            }
            return rev_num;
        }
        public static void Main()
        {
            int num = 1235;
            Console.Write("Reverse of no. is "
                            + reversDigits(num));
            Console.ReadLine();
        }


    }
}

